import { 
    fetchCities, fetchCompanies, fetchDependencies, fetchUsers, 
    supabaseOrders, fetchServiceTypes, fetchAppSettings, fetchEquipmentTypes, 
    fetchRefrigerantTypes, fetchAllEquipment, fetchAllEnrichedOrders, fetchAllReports 
} from './api';
import { setupEventListeners } from './events';
import { initSignaturePad, hideLoader, showLoader, showAppNotification, populateLoginWorkerSelect } from './ui';
import { initQrScanner } from './lib/qr-scanner';
import * as D from './dom';
import { openReportFormModal } from './ui';
import * as State from './state';
import { Database, AppSettings, Report } from './types';
import { checkForPersistedSession } from './auth';
import { initDB, getAllFromStore, cacheAllData } from './lib/local-db';
import { synchronizeQueue, startPeriodicSync } from './lib/sync';


async function seedInitialUsers(initialUsers: any[]) {
    let usersNeedRefetch = false;

    const adminUserExists = initialUsers.some(u => u.username === 'admin');
    if (!adminUserExists) {
        console.log("Seeding Admin user...");
        const adminUserData: Database['public']['Tables']['maintenance_users']['Insert'] = {
            username: 'admin',
            password: 'admin123',
            role: 'admin',
            name: 'Administrador Principal',
            cedula: 'admin001',
            is_active: true,
        };
        const { error } = await supabaseOrders.from('maintenance_users').insert([adminUserData] as any);
        if (error) console.error("Error seeding admin:", error);
        else usersNeedRefetch = true;
    }

    if (usersNeedRefetch) {
        console.log("Refetching users after seeding...");
        const finalUsers = await fetchUsers();
        State.setUsers(finalUsers);
    }
}

async function synchronizeAndLoadData() {
    showLoader('Cargando datos locales...');
    const [
        localUsers, localCities, localCompanies, localDependencies,
        localEquipment, localServiceTypes, localEquipmentTypes,
        localRefrigerantTypes, localAppSettings, localReports, localOrders,
        localQueuedReports
    ] = await Promise.all([
        getAllFromStore('users'), getAllFromStore('cities'), getAllFromStore('companies'),
        getAllFromStore('dependencies'), getAllFromStore('equipment'), getAllFromStore('service_types'),
        getAllFromStore('equipment_types'), getAllFromStore('refrigerant_types'), getAllFromStore('app_settings'),
        getAllFromStore('reports'), getAllFromStore('orders'),
        getAllFromStore('reports_queue'),
    ]);

    const hasLocalData = localUsers.length > 0 && localCities.length > 0;

    if (hasLocalData) {
        console.log("Datos locales encontrados. Cargando desde IndexedDB.");
        State.setUsers(localUsers);
        State.setCities(localCities);
        State.setCompanies(localCompanies);
        State.setDependencies(localDependencies);
        State.setEquipmentList(localEquipment);
        State.setServiceTypes(localServiceTypes);
        State.setEquipmentTypes(localEquipmentTypes);
        State.setRefrigerantTypes(localRefrigerantTypes);
        const settings: AppSettings = {};
        localAppSettings.forEach(s => settings[s.key] = s.value);
        State.setAppSettings(settings);
        
        // Combine reports from main cache and queue
        const combinedLocalReports = [...localQueuedReports, ...localReports];
        const localReportMap = new Map(combinedLocalReports.map(r => [r.id, r]));
        State.setReports(Array.from(localReportMap.values()));

        State.setAllServiceOrders(localOrders);
    }

    const isOnline = navigator.onLine;
    if (isOnline) {
        try {
            showLoader(hasLocalData ? 'Actualizando datos...' : 'Descargando datos necesarios...');
            
            // Step 1: Fetch data that has no dependencies
            const [ usersData, appSettingsData, citiesData, companiesData, dependenciesData,
                equipmentData, serviceTypesData, equipmentTypesData, refrigerantTypesData, allReportsData ] = await Promise.all([
                fetchUsers(), fetchAppSettings(), fetchCities(), fetchCompanies(), fetchDependencies(),
                fetchAllEquipment(), fetchServiceTypes(), fetchEquipmentTypes(), fetchRefrigerantTypes(), fetchAllReports()
            ]);
            
            // Set users state so dependent fetches can use it
            State.setUsers(usersData);

            // Step 2: Fetch data that depends on users
            const allEnrichedOrdersData = await fetchAllEnrichedOrders(usersData);
            
            // Step 2.5: Get reports from the offline queue
            const allQueuedReportsData = await getAllFromStore('reports_queue');


            // Step 3: Set all state, combining reports
            State.setAppSettings(appSettingsData);
            State.setCities(citiesData);
            State.setCompanies(companiesData);
            State.setDependencies(dependenciesData);
            State.setEquipmentList(equipmentData);
            State.setServiceTypes(serviceTypesData);
            State.setEquipmentTypes(equipmentTypesData);
            State.setRefrigerantTypes(refrigerantTypesData);
            
            const combinedReports = [...allQueuedReportsData, ...allReportsData];
            const reportMap = new Map(combinedReports.map(r => [r.id, r]));
            State.setReports(Array.from(reportMap.values()));
            
            State.setAllServiceOrders(allEnrichedOrdersData);
            
            console.log("Datos frescos obtenidos. Estado de la aplicación actualizado.");

            // Step 4: Cache everything in parallel (only cache synced reports in 'reports')
            await Promise.all([
                cacheAllData('users', usersData),
                cacheAllData('cities', citiesData),
                cacheAllData('companies', companiesData),
                cacheAllData('dependencies', dependenciesData),
                cacheAllData('equipment', equipmentData),
                cacheAllData('service_types', serviceTypesData),
                cacheAllData('equipment_types', equipmentTypesData),
                cacheAllData('refrigerant_types', refrigerantTypesData),
                cacheAllData('app_settings', Object.entries(appSettingsData).map(([key, value]) => ({ key, value }))),
                cacheAllData('reports', allReportsData),
                cacheAllData('orders', allEnrichedOrdersData)
            ]);
            
            console.log("Actualización de caché completa.");

            await seedInitialUsers(usersData);

        } catch (error: any) {
            console.error("Error al sincronizar datos:", error);
            if (!hasLocalData) {
                throw new Error("No se pudieron cargar los datos y no hay caché local. La aplicación no puede continuar.");
            }
            showAppNotification("Sin conexión. Usando datos guardados localmente.", 'info');
        }
    } else {
        if (!hasLocalData) {
            throw new Error("Estás sin conexión y no hay datos locales guardados. La aplicación no puede iniciar.");
        }
        showAppNotification("Sin conexión. Usando datos guardados localmente.", 'info');
    }
}


export async function main() {
    // 1. Registrar el Service Worker y manejar la activación inicial
    if ('serviceWorker' in navigator) {
        try {
            const registration = await navigator.serviceWorker.register('/sw.js');
            console.log('Service Worker registrado con éxito. Scope:', registration.scope);

            // --- INICIO DE LA SOLUCIÓN ---
            // Este bloque de código soluciona el problema de la "doble recarga".
            // Detecta cuándo un nuevo Service Worker se ha instalado por primera vez
            // y recarga la página automáticamente para que tome el control. Esto asegura
            // que los assets (CSS, JS) se sirvan desde el caché en la siguiente visita,
            // permitiendo un funcionamiento offline inmediato.
            let refreshing = false;
            registration.addEventListener('updatefound', () => {
                const newWorker = registration.installing;
                if (newWorker) {
                    newWorker.addEventListener('statechange', () => {
                        // Si el nuevo SW se ha instalado y está esperando, y no hay un controlador activo,
                        // significa que es la primera vez y necesitamos refrescar para que tome el control.
                        if (newWorker.state === 'installed' && !navigator.serviceWorker.controller) {
                            console.log('[SW] Nuevo Service Worker instalado, refrescando para activar...');
                            if (!refreshing) {
                                refreshing = true;
                                window.location.reload();
                            }
                        }
                    });
                }
            });
            // --- FIN DE LA SOLUCIÓN ---

        } catch (error) {
            console.error('Error al registrar el Service Worker:', error);
        }
    }

    // 2. Continuar con el resto de la inicialización de la app
    showLoader('Iniciando aplicación...');
    try {
        await initDB();

        const version = localStorage.getItem(State.DATA_VERSION_KEY);
        if (version !== State.CURRENT_DATA_VERSION) {
            console.warn(`Version mismatch. Stored: ${version}, Current: ${State.CURRENT_DATA_VERSION}. Clearing localStorage.`);
            localStorage.clear();
            localStorage.setItem(State.DATA_VERSION_KEY, State.CURRENT_DATA_VERSION);
        }
        
        await synchronizeAndLoadData();
        
        populateLoginWorkerSelect();
        checkForPersistedSession();

        // After session is potentially restored, and before event listeners are set up,
        // try an initial sync if the app starts online.
        if (navigator.onLine) {
            await synchronizeQueue();
        } else {
            // If starting offline, begin periodic checks immediately.
            startPeriodicSync();
        }

        setupEventListeners();
        initSignaturePad();
        initQrScanner({
            scanQrCameraButton: D.scanQrCameraButton,
            scanQrFromFileButton: D.scanQrFromFileButton,
            qrFileInput: D.qrFileInput,
            cameraScanModal: D.cameraScanModal,
            closeCameraScanModalButton: D.closeCameraScanModalButton,
            qrVideoElement: D.qrVideoElement,
            qrHiddenCanvasElement: D.qrHiddenCanvasElement,
            cancelCameraScanButton: D.cancelCameraScanButton,
            cameraScanFeedback: D.cameraScanFeedback,
            showLoader,
            hideLoader,
            showAppNotification,
            handleQrCodeResult: (qrData) => {
                showLoader('Procesando QR...');
                try {
                    const manualId = qrData.trim();
                    if (manualId) {
                        const equipment = State.equipmentList.find(eq => 
                            eq.manualId?.trim().toLowerCase() === manualId.toLowerCase()
                        );
                        if (equipment) {
                            showAppNotification(`Equipo encontrado: ${equipment.brand} ${equipment.model}`, 'success');
                            openReportFormModal({ equipment, category: equipment.category as any });
                        } else {
                            showAppNotification(`Equipo con ID Manual '${manualId}' no fue encontrado en la base de datos.`, 'error', 5000);
                        }
                    } else {
                        throw new Error("El código QR está vacío.");
                    }
                } catch (e: any) {
                    showAppNotification('El código QR no es válido o está vacío.', 'error');
                    console.error("Error processing QR data:", e.message || e);
                } finally {
                    hideLoader();
                }
            }
        });

        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
        if (isIOS && D.toggleFullscreenButton) {
            D.toggleFullscreenButton.style.display = 'none';
        }
        
    } catch (error: any) {
        console.error("Failed during app initialization:", error);
        showAppNotification(error.message || 'Error crítico al iniciar la aplicación.', 'error', 10000);
        hideLoader();
    }
}