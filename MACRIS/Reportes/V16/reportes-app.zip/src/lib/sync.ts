import { getQueuedReports, removeReportFromQueue, QueuedReport, getQueuedEntities, removeEntityFromQueue, QueuedEntity, addOrUpdateItemInStore, getAllFromStore } from './local-db';
import { supabaseOrders, upsertMaintenanceReport, updateOrderStatus, awardPointToTechnician, fetchAllReports, fetchReportsForWorker, fetchCompanies, fetchCities, fetchDependencies, fetchEquipmentTypes, fetchRefrigerantTypes } from '../api';
import { showAppNotification, renderMyReportsTable, renderAdminReportsTable, renderAssignedOrdersList, renderAdminOrdersList, updateUserPointsDisplay } from '../ui';
import * as State from '../state';
import { EntityType } from '../types';

let isSyncing = false; // Simple lock to prevent concurrent syncs
// This map will hold the mapping from temporary local IDs to permanent server IDs during a sync cycle.
const localToServerIdMap = new Map<string, string>();

let periodicSyncIntervalId: number | null = null;
const SYNC_INTERVAL = 30 * 1000; // 30 seconds

export function startPeriodicSync() {
    if (periodicSyncIntervalId !== null) {
        console.log('[Sync] Periodic sync is already running.');
        return;
    }
    console.log(`[Sync] Starting periodic sync every ${SYNC_INTERVAL / 1000} seconds.`);
    periodicSyncIntervalId = window.setInterval(() => {
        console.log('[Periodic Sync] Interval triggered. Checking for sync...');
        synchronizeQueue();
    }, SYNC_INTERVAL);
}

export function stopPeriodicSync() {
    if (periodicSyncIntervalId !== null) {
        console.log('[Sync] Stopping periodic sync.');
        clearInterval(periodicSyncIntervalId);
        periodicSyncIntervalId = null;
    }
}

async function syncEntitiesQueue(): Promise<boolean> {
    const queuedEntities = await getQueuedEntities();
    if (queuedEntities.length === 0) {
        console.log('[Sync] No entities in queue to sync.');
        return true; // Nothing to do, so it's a "success"
    }

    console.log(`[Sync] Found ${queuedEntities.length} entities to sync.`);
    let allSucceeded = true;

    // Define the order of synchronization based on dependencies
    const syncOrder: EntityType[] = ['city', 'company', 'dependency', 'equipmentType', 'refrigerant'];
    const sortedEntities = queuedEntities.sort((a, b) => {
        return syncOrder.indexOf(a.type) - syncOrder.indexOf(b.type);
    });

    for (const entity of sortedEntities) {
        try {
            const { localId, type, payload } = entity;
            // The payload already contains a temporary `id` property which we need to remove before inserting.
            const { id, ...originalPayload } = payload;
            let insertPayload = { ...originalPayload };
            
            // --- ID REMAPPING LOGIC ---
            if (type === 'company' && insertPayload.city_id && insertPayload.city_id.startsWith('local_')) {
                const serverCityId = localToServerIdMap.get(insertPayload.city_id);
                if (!serverCityId) throw new Error(`Parent city with local ID ${insertPayload.city_id} has not been synced yet.`);
                insertPayload.city_id = serverCityId;
            }
            if (type === 'dependency' && insertPayload.company_id && insertPayload.company_id.startsWith('local_')) {
                const serverCompanyId = localToServerIdMap.get(insertPayload.company_id);
                if (!serverCompanyId) throw new Error(`Parent company with local ID ${insertPayload.company_id} has not been synced yet.`);
                insertPayload.company_id = serverCompanyId;
            }
            // --- END OF ID REMAPPING ---

            let tableName: string;
            switch(type) {
                case 'city': tableName = 'maintenance_cities'; break;
                case 'company': tableName = 'maintenance_companies'; break;
                case 'dependency': tableName = 'maintenance_dependencies'; break;
                case 'equipmentType': tableName = 'maintenance_equipment_types'; break;
                case 'refrigerant': tableName = 'maintenance_refrigerant_types'; break;
                default:
                    throw new Error(`Sync for entity type "${type}" is not implemented.`);
            }

            // IMPORTANT: We need to get the created entity back to get its new server-side UUID
            const { data: newServerEntity, error } = await supabaseOrders
                .from(tableName)
                .insert(insertPayload)
                .select()
                .single();

            if (error) {
                if (error.code === '23505') { // Duplicate error
                    console.warn(`[Sync] Entity ${localId} might already exist. Removing from queue.`);
                    await removeEntityFromQueue(localId);
                } else {
                    throw error;
                }
            // FIX: Check for newServerEntity to ensure it's not null before use.
            } else if (newServerEntity) {
                // Success! Map the local ID to the new server ID and remove from queue
                // FIX: Cast newServerEntity to `any` to access the `id` property, as its type cannot be inferred from a dynamic table name.
                localToServerIdMap.set(localId, (newServerEntity as any).id);
                await removeEntityFromQueue(localId);
                // FIX: Cast newServerEntity to `any` to access the `id` property, as its type cannot be inferred from a dynamic table name.
                console.log(`[Sync] Successfully synced entity ${localId}. New server ID: ${(newServerEntity as any).id}`);
            } else {
                // This case is unlikely after a successful insert but good to handle.
                throw new Error(`[Sync] Insert succeeded but failed to retrieve new entity for local ID ${localId}.`);
            }
        } catch (error: any) {
            allSucceeded = false;
            console.error(`[Sync] Failed to sync entity ${entity.localId}:`, error);
            showAppNotification(`Error al sincronizar la entidad: ${entity.payload.name || entity.type}.`, 'error');
        }
    }
    
    // After syncing, refetch the master data to update the app state
    if (queuedEntities.length > 0 && allSucceeded) {
        console.log('[Sync] Refetching master data after entity sync...');
        await Promise.all([
            fetchCities().then(State.setCities),
            fetchCompanies().then(State.setCompanies),
            fetchDependencies().then(State.setDependencies),
            fetchEquipmentTypes().then(State.setEquipmentTypes),
            fetchRefrigerantTypes().then(State.setRefrigerantTypes),
        ]);
        console.log('[Sync] Master data refetched.');
    }

    return allSucceeded;
}

export async function synchronizeQueue(): Promise<void> {
    if (isSyncing) {
        console.log('[Sync] Aborted: Sync already in progress.');
        return;
    }
    if (!navigator.onLine) {
        console.log('[Sync] Aborted: Offline.');
        return;
    }
    
    if (!State.currentUser) {
        console.log('[Sync] Aborted: No user is currently logged in.');
        return;
    }

    isSyncing = true;
    localToServerIdMap.clear(); // Clear the map at the start of each new sync process
    console.log('[Sync] Lock acquired. Starting synchronization process...');

    try {
        // --- STEP 1: Sync Entities First ---
        console.log('[Sync] === Phase 1: Syncing Entities ===');
        const entitiesSyncedSuccessfully = await syncEntitiesQueue();
        if (!entitiesSyncedSuccessfully) {
            console.warn('[Sync] Not all entities synced successfully. Halting report sync to prevent data integrity issues.');
            showAppNotification('Algunas entidades no se pudieron sincronizar. La sincronización de reportes se reintentará más tarde.', 'warning');
            return;
        }
        console.log('[Sync] === Phase 1 Complete ===');

        // --- STEP 2: Sync Reports ---
        console.log('[Sync] === Phase 2: Syncing Reports ===');
        const queuedReports = await getQueuedReports();

        if (queuedReports.length === 0) {
            console.log("[Sync] No reports in queue to sync.");
            return;
        }

        showAppNotification(`Conexión detectada. Sincronizando ${queuedReports.length} reporte(s)...`, 'info', 5000);

        let successCount = 0;
        let failCount = 0;

        for (const report of queuedReports) {
            try {
                const { localId, status, ...reportToSync } = report;
                
                // --- ID REMAPPING FOR REPORTS ---
                if (reportToSync.cityId && reportToSync.cityId.startsWith('local_')) {
                    const serverId = localToServerIdMap.get(reportToSync.cityId);
                    if (serverId) reportToSync.cityId = serverId;
                    else console.warn(`[Sync] Could not find server ID for local city ID: ${reportToSync.cityId}`);
                }
                if (reportToSync.companyId && reportToSync.companyId.startsWith('local_')) {
                    const serverId = localToServerIdMap.get(reportToSync.companyId);
                    if (serverId) reportToSync.companyId = serverId;
                    else console.warn(`[Sync] Could not find server ID for local company ID: ${reportToSync.companyId}`);
                }
                if (reportToSync.dependencyId && reportToSync.dependencyId.startsWith('local_')) {
                    const serverId = localToServerIdMap.get(reportToSync.dependencyId);
                    if (serverId) reportToSync.dependencyId = serverId;
                    else console.warn(`[Sync] Could not find server ID for local dependency ID: ${reportToSync.dependencyId}`);
                }
                // --- END ID REMAPPING ---

                const reportForDb = {
                    id: reportToSync.id,
                    timestamp: reportToSync.timestamp,
                    service_type: reportToSync.serviceType,
                    observations: reportToSync.observations,
                    equipment_snapshot: reportToSync.equipmentSnapshot as any,
                    items_snapshot: reportToSync.itemsSnapshot,
                    city_id: reportToSync.cityId,
                    company_id: reportToSync.companyId,
                    dependency_id: reportToSync.dependencyId,
                    worker_id: reportToSync.workerId,
                    worker_name: reportToSync.workerName,
                    client_signature: reportToSync.clientSignature,
                    pressure: reportToSync.pressure,
                    amperage: reportToSync.amperage,
                    is_paid: reportToSync.is_paid,
                    photo_internal_unit_url: reportToSync.photo_internal_unit_url,
                    photo_external_unit_url: reportToSync.photo_external_unit_url,
                    order_id: reportToSync.orderId || null,
                };

                await upsertMaintenanceReport(reportForDb);

                if (report.orderId) {
                    await updateOrderStatus(report.orderId, 'completed');
                    State.updateOrderInState(report.orderId, { status: 'completed' });
                }
                
                if (State.currentUser.id === report.workerId) {
                     const { error: pointError } = await awardPointToTechnician(report.workerId);
                     if (!pointError && State.currentUser.points !== undefined && State.currentUser.points !== null) {
                        if (State.currentUser) {
                            State.currentUser.points++;
                        }
                     } else if (pointError) {
                         console.warn(`[Sync] Failed to award point for report ${report.localId}, but sync will continue.`, pointError);
                     }
                }

                // **CRITICAL FIX**: After successful sync, add to the main `reports` cache
                // before removing from the queue. This ensures offline availability.
                await addOrUpdateItemInStore('reports', reportToSync);

                await removeReportFromQueue(localId);
                successCount++;

            } catch (error: any) {
                console.error(`[Sync] Failed to sync report ${report.localId}:`, error);
                if (error.code === '23505') { 
                    showAppNotification(`Reporte ${report.localId.substring(0,8)} ya existe. Eliminando de la cola.`, 'info');
                    // Even if it's a duplicate, ensure it's in the local cache
                    const { localId, status, ...reportToCache } = report;
                    await addOrUpdateItemInStore('reports', reportToCache);
                    await removeReportFromQueue(report.localId);
                } else {
                    showAppNotification(`Error al sincronizar reporte ${report.localId.substring(0,8)}.`, 'error');
                    failCount++;
                }
            }
        }

        if (successCount > 0) {
            showAppNotification(`${successCount} reporte(s) sincronizado(s).`, 'success');
        }
        if (failCount === 0 && successCount > 0) {
            showAppNotification('Sincronización completada.', 'success', 2000);
        }
        
        if (successCount > 0) {
            showAppNotification('Actualizando listas...', 'info', 1500);
            // After sync, the in-memory state might be out of date.
            // Let's rebuild it from the updated local DB stores.
            const [syncedReports, stillQueued] = await Promise.all([
                getAllFromStore('reports'),
                getQueuedReports()
            ]);
            
            const combined = [...stillQueued, ...syncedReports];
            const reportMap = new Map(combined.map(r => [r.id, r]));
            State.setReports(Array.from(reportMap.values()));


            if (State.currentUser.role === 'worker') {
                renderMyReportsTable();
                renderAssignedOrdersList();
            } else {
                renderAdminReportsTable();
                renderAdminOrdersList();
            }
            updateUserPointsDisplay(State.currentUser.points);
        }
        console.log('[Sync] === Phase 2 Complete ===');

    } catch (error) {
        console.error("[Sync] A critical error occurred during the sync process:", error);
        showAppNotification('Ocurrió un error inesperado durante la sincronización.', 'error');
    } finally {
        isSyncing = false;
        console.log('[Sync] Lock released. Synchronization process finished.');
    }
}