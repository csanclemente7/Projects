import { supabaseOrders, fetchAssignedOrders } from './api';
import * as State from './state';
import * as D from './dom';
import { populateBottomNav, showView, showLoader, hideLoader, showAppNotification, populateAdminFilterDropdowns, renderAdminOrdersList, populateAdminOrderFilterDropdowns, updateUserPointsDisplay, renderAssignedOrdersList } from './ui';
import { User, Order } from './types';
import { checkOnlineStatus } from './utils';

const USER_SESSION_KEY = 'maintenance_app_current_user';

export function checkForPersistedSession() {
    const storedUserJSON = localStorage.getItem(USER_SESSION_KEY);
    if (storedUserJSON) {
        try {
            const storedUser = JSON.parse(storedUserJSON) as User;
            // It's crucial to find the user in the fresh list from the DB
            // to ensure their data (like isActive) is current.
            const userFromState = State.users.find(u => u.id === storedUser.id);
            
            if (userFromState && userFromState.isActive) {
                console.log("Found persisted session. Logging in user automatically.", userFromState);
                handlePostLogin(userFromState);
            } else {
                // User might have been deactivated or deleted. Clear the session.
                console.log("Found persisted session for an inactive/deleted user. Clearing session.");
                localStorage.removeItem(USER_SESSION_KEY);
                hideLoader(); // Hide loader if session was invalid
            }
        } catch (error) {
            console.error("Failed to parse persisted user session:", error);
            localStorage.removeItem(USER_SESSION_KEY);
            hideLoader(); // Hide loader on error
        }
    } else {
        console.log("No persisted session found. Showing login screen.");
        hideLoader(); // Hide loader if no session exists
    }
}

async function handlePostLogin(user: User) {
    State.setCurrentUser(user);
    const userToStore = { ...user };
    delete userToStore.password;
    localStorage.setItem(USER_SESSION_KEY, JSON.stringify(userToStore));
    
    showLoader('Cargando datos de sesión...');
    try {
        if (user.role === 'worker') {
            let orders: Order[];
            
            showLoader('Cargando sus órdenes...');
            try {
                // Attempt online fetch first
                orders = await fetchAssignedOrders(user.id, State.users);
            } catch (error: any) {
                // Check for a network error specifically
                if (error.message && error.message.includes('Failed to fetch')) {
                    console.warn('Online fetch for orders failed. Falling back to local data.');
                    showAppNotification('Sin conexión. Cargando órdenes locales.', 'info');
                    
                    // Fallback to local data
                    orders = State.allServiceOrders.filter(o => o.assignedTechnicians?.some(t => t.id === user.id));
                } else {
                    // It's a different error (e.g., server error), so we should let it fail
                    throw error;
                }
            }
            
            State.setAssignedOrders(orders);
            console.log(`Worker login complete. ${orders.length} assigned orders loaded.`);
            // Explicitly render the list to avoid needing a page refresh
            renderAssignedOrdersList();

            startAppSession();
            hideLoader();

            const pendingOrders = orders.filter(o => o.status !== 'completed' && o.status !== 'cancelada');
            if (pendingOrders.length > 0) {
                showAppNotification(`Tiene ${pendingOrders.length} órdenes de servicio pendientes.`, 'info');
            }

        } else if (user.role === 'admin') {
            if (!navigator.onLine) {
                showAppNotification("Modo sin conexión. Mostrando datos locales.", "info");
            }
            // Populate filters with the already loaded shared data.
            populateAdminFilterDropdowns();
            populateAdminOrderFilterDropdowns();

            // Explicitly render the list to avoid needing a page refresh
            renderAdminOrdersList();
            
            // Finalize UI setup and make the app interactive.
            startAppSession();
            hideLoader();
        }

    } catch (error) {
        console.error('Failed to load application data after login:', error);
        showAppNotification('Error al cargar los datos. Por favor, intente de nuevo.', 'error');
        handleLogout(); // Log out to prevent being in a broken state
    }
}


export function startAppSession() {
    if (!D.loginScreen || !D.appScreen || !D.bottomNav || !D.currentUserDisplay || !State.currentUser || !D.changePasswordActionButton) return;
    D.loginScreen.style.display = 'none';
    D.appScreen.style.display = 'block';
    D.bottomNav.style.display = 'flex';

    document.body.dataset.userRole = State.currentUser.role;

    D.currentUserDisplay.textContent = `${State.currentUser.name || State.currentUser.username}`;

    populateBottomNav(State.currentUser.role);
    updateUserPointsDisplay(State.currentUser.points); // Display points on login


    if (State.currentUser.role === 'admin') {
        D.changePasswordActionButton.style.display = 'inline-flex';
        // Trigger click on the first nav item for admin to load its initial data
        const firstNavItem = D.bottomNav.querySelector('.nav-item') as HTMLButtonElement | null;
        firstNavItem?.click();
    } else { // Worker
        D.changePasswordActionButton.style.display = 'none';
        // Trigger click on the first nav item for worker
        const firstNavItem = D.bottomNav.querySelector('.nav-item') as HTMLButtonElement | null;
        firstNavItem?.click();
    }
}

export async function handleLogin(e: SubmitEvent) {
    e.preventDefault();
    if (!D.usernameInput || !D.passwordInput || !D.loginError) return;
    D.loginError.textContent = '';

    const userId = D.usernameInput.value;
    const password = D.passwordInput.value; // This is the cedula

    if (!userId) {
        D.loginError.textContent = 'Por favor, seleccione su nombre.';
        return;
    }

    const user = State.users.find(u => u.id === userId);

    if (user && user.password === password) {
        if (user.isActive) {
            await handlePostLogin(user);
        } else {
            D.loginError.textContent = 'Este usuario está inactivo. Contacte al administrador.';
        }
    } else {
        D.loginError.textContent = 'Contraseña (cédula) incorrecta.';
    }
}

export function handleLogout() {
    State.setCurrentUser(null);
    State.setAssignedOrders([]); // Clear orders on logout
    State.setAllServiceOrders([]);
    localStorage.removeItem(USER_SESSION_KEY);
    if (D.loginScreen) D.loginScreen.style.display = 'flex';
    if (D.appScreen) D.appScreen.style.display = 'none';
    if (D.bottomNav) D.bottomNav.style.display = 'none';
    if (D.loginForm) D.loginForm.reset();
    document.body.removeAttribute('data-user-role');
}

export function openAdminPasswordModal() {
    if (!D.adminPasswordModal) return;
    D.adminPasswordModal.style.display = 'flex';
    if (D.adminPasswordInput) {
        D.adminPasswordForm.reset();
        D.adminPasswordError.textContent = '';
        setTimeout(() => D.adminPasswordInput.focus(), 100); // Focus after transition
    }
}

export async function handleAdminPasswordSubmit(e: SubmitEvent) {
    e.preventDefault();
    if (!D.adminPasswordInput || !D.adminPasswordError) return;

    showLoader("Verificando conexión...");
    const isOnline = await checkOnlineStatus();
    hideLoader();

    if (!isOnline) {
        D.adminPasswordError.textContent = 'Se requiere conexión a internet para el acceso de administrador.';
        showAppNotification('El acceso de administrador requiere una conexión a internet activa.', 'warning');
        return; // Stop the login process
    }

    const password = D.adminPasswordInput.value;
    const adminUser = State.users.find(u => u.username === 'admin' && u.password === password);

    if (adminUser) {
        closeAdminPasswordModal();
        await handlePostLogin(adminUser);
    } else {
        if (D.adminPasswordError) D.adminPasswordError.textContent = 'Contraseña de administrador incorrecta.';
    }
}

export function closeAdminPasswordModal() {
    if (D.adminPasswordModal) D.adminPasswordModal.style.display = 'none';
}


export function openChangePasswordModal() {
    if (!D.changePasswordModal || !D.changePasswordForm || !State.currentUser || State.currentUser.role !== 'admin') return;
    D.changePasswordForm.reset();
    if (D.changePasswordError) D.changePasswordError.textContent = '';
    D.changePasswordModal.style.display = 'flex';
}

export async function handleChangePasswordSubmit(e: SubmitEvent) {
    e.preventDefault();
    if (!State.currentUser || State.currentUser.role !== 'admin' || !D.changePasswordError) return;

    const currentPassword = D.currentPasswordInput.value;
    const newPassword = D.newPasswordInput.value;
    const confirmPassword = D.confirmNewPasswordInput.value;

    if (currentPassword !== State.currentUser.password) {
        D.changePasswordError.textContent = 'La contraseña actual es incorrecta.';
        return;
    }
    if (newPassword.length < 6) {
        D.changePasswordError.textContent = 'La nueva contraseña debe tener al menos 6 caracteres.';
        return;
    }
    if (newPassword !== confirmPassword) {
        D.changePasswordError.textContent = 'Las nuevas contraseñas no coinciden.';
        return;
    }

    showLoader("Cambiando contraseña...");
    const { error } = await supabaseOrders.from('maintenance_users').update({ password: newPassword }).eq('id', State.currentUser.id);
    hideLoader();

    if (error) {
        D.changePasswordError.textContent = `Error al actualizar: ${error.message}`;
        showAppNotification('Error al cambiar contraseña.', 'error');
    } else {
        // Update local user object
        const updatedUser = { ...State.currentUser, password: newPassword };
        State.setCurrentUser(updatedUser);
        
        // Update persisted session data
        const userToStore = { ...updatedUser };
        delete userToStore.password;
        localStorage.setItem(USER_SESSION_KEY, JSON.stringify(userToStore));

        showAppNotification('Contraseña cambiada con éxito.', 'success');
        closeChangePasswordModal();
    }
}

export function closeChangePasswordModal() {
    if (D.changePasswordModal) D.changePasswordModal.style.display = 'none';
}